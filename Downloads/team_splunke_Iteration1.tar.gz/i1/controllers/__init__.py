pink = "klkad"
